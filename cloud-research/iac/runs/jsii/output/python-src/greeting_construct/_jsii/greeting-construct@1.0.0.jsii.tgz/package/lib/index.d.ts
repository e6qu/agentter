/** A greeting, expressed once in TypeScript and exposed to every jsii target. */
export interface GreeterProps {
    /** Who to greet. */
    readonly name: string;
    /** Optional number of exclamation marks. @default 1 */
    readonly enthusiasm?: number;
}
/** Builds greetings. jsii exposes this class to Python, Java, .NET, Go. */
export declare class Greeter {
    private readonly name;
    private readonly enthusiasm;
    constructor(props: GreeterProps);
    /** Return the greeting string. */
    greet(): string;
}
